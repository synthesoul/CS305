package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

}

// RestController to handle the checksum route
@RestController
class ChecksumController {

    @GetMapping("/checksum")
    public String getChecksum(@RequestParam String data) throws NoSuchAlgorithmException {
        // Create SHA-256 MessageDigest instance
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        
        // Calculate the checksum (SHA-256 hash)
        byte[] hash = digest.digest(data.getBytes());
        
        // Convert the hash bytes into a hexadecimal string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            hexString.append(String.format("%02x", b));
        }
        
        // Return the checksum (SHA-256 hash) as a string
        return hexString.toString();
    }
}
